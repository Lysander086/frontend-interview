# Vuex 1.0 Docs

- [English](https://github.com/vuejs/vuex/tree/1.0/docs/en)
- [Chinese](https://github.com/vuejs/vuex/tree/1.0/docs/zh-cn)
- [Japanese](https://github.com/vuejs/vuex/tree/1.0/docs/ja)
- [Spanish](https://github.com/vuejs/vuex/tree/1.0/docs/es)
- [Portuguese](https://github.com/vuejs/vuex/tree/1.0/docs/pt)
- [Italian](https://github.com/vuejs/vuex/tree/1.0/docs/it)
