# Conceitos Básicos

Vamos aprender os conceitos básicos do Vuex nestes capítulos. São eles:

- [Estado](state.md)
- [Getters](getters.md)
- [Mutações](mutations.md)
- [Ações](actions.md)
- [Módulos](modules.md)

Uma compreensão profunda de todos esses conceitos é essencial para o uso de vuex.

Vamos começar.
