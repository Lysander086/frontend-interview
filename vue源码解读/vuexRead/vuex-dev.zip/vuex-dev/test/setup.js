import 'regenerator-runtime/runtime'
import Vue from 'vue'
import Vuex from '@/index'

Vue.use(Vuex)
